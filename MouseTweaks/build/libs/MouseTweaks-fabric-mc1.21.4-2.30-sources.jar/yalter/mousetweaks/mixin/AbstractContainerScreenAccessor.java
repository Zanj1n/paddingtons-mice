package yalter.mousetweaks.mixin;

import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_465;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_465.class)
public interface AbstractContainerScreenAccessor {
    @Invoker("getHoveredSlot")
    class_1735 mousetweaks$invokeGetHoveredSlot(double x, double y);

    @Invoker("slotClicked")
    void mousetweaks$invokeSlotClicked(class_1735 slot, int index, int button, class_1713 clickType);

    @Accessor("isQuickCrafting")
    boolean mousetweaks$getIsQuickCrafting();

    @Accessor("isQuickCrafting")
    void mousetweaks$setIsQuickCrafting(boolean value);

    @Accessor("quickCraftingButton")
    int mousetweaks$getQuickCraftingButton();

    @Accessor("skipNextRelease")
    void mousetweaks$setSkipNextRelease(boolean value);

    @Accessor("leftPos")
    int mousetweaks$getLeftPos();

    @Accessor("topPos")
    int mousetweaks$getTopPos();
}
