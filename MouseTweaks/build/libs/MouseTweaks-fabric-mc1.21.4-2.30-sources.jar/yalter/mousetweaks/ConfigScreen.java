package yalter.mousetweaks;

import net.minecraft.class_2561;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_5244;
import net.minecraft.class_5676;
import net.minecraft.class_7842;

public class ConfigScreen extends class_437 {
    private final class_437 previous;

    public ConfigScreen(class_437 previous) {
        super(class_2561.method_43470("Mouse Tweaks Options"));
        this.previous = previous;
    }

    @Override
    protected void method_25426() {
        Main.config.read();

        this.method_37063(new class_7842(this.field_22789 / 2 - this.field_22793.method_27525(this.field_22785) / 2, 15, this.field_22789, 9, this.field_22785, this.field_22793));

        this.method_37063(class_5676.method_32613(Main.config.rmbTweak)
                .method_32617(this.field_22789 / 2 - 155, this.field_22790 / 6, 150, 20,
                        class_2561.method_43470("RMB Tweak"), (button, value) -> Main.config.rmbTweak = value));

        this.method_37063(class_5676.method_32613(Main.config.wheelTweak)
                .method_32617(this.field_22789 / 2 - 155, this.field_22790 / 6 + 24, 150, 20,
                        class_2561.method_43470("Wheel Tweak"), (button, value) -> Main.config.wheelTweak = value));

        this.method_37063(class_5676.method_32613(Main.config.lmbTweakWithItem)
                .method_32617(this.field_22789 / 2 + 5, this.field_22790 / 6, 150, 20,
                        class_2561.method_43470("LMB Tweak With Item"), (button, value) -> Main.config.lmbTweakWithItem = value));

        this.method_37063(class_5676.method_32613(Main.config.lmbTweakWithoutItem)
                .method_32617(this.field_22789 / 2 + 5, this.field_22790 / 6 + 24, 150, 20,
                        class_2561.method_43470("LMB Tweak Without Item"), (button, value) -> Main.config.lmbTweakWithoutItem = value));

        this.method_37063(
                class_5676.<WheelSearchOrder>method_32606(value -> class_2561.method_43470(switch (value) {
                            case FIRST_TO_LAST -> "First to Last";
                            case LAST_TO_FIRST -> "Last to First";
                        }))
                        .method_32624(WheelSearchOrder.FIRST_TO_LAST, WheelSearchOrder.LAST_TO_FIRST)
                        .method_32619(Main.config.wheelSearchOrder)
                        .method_32617(this.field_22789 / 2 - 155, this.field_22790 / 6 + 24 * 2, 310, 20,
                                class_2561.method_43470("Wheel Tweak Search Order"), (button, value) -> Main.config.wheelSearchOrder = value));

        this.method_37063(
                class_5676.<WheelScrollDirection>method_32606(value -> class_2561.method_43470(switch (value) {
                            case NORMAL -> "Down to Push, Up to Pull";
                            case INVERTED -> "Up to Push, Down to Pull";
                            case INVENTORY_POSITION_AWARE -> "Inventory Position Aware";
                            case INVENTORY_POSITION_AWARE_INVERTED -> "Inventory Position Aware, Inverted";
                        }))
                        .method_32624(WheelScrollDirection.NORMAL, WheelScrollDirection.INVERTED, WheelScrollDirection.INVENTORY_POSITION_AWARE, WheelScrollDirection.INVENTORY_POSITION_AWARE_INVERTED)
                        .method_32619(Main.config.wheelScrollDirection)
                        .method_32617(this.field_22789 / 2 - 155, this.field_22790 / 6 + 24 * 3, 310, 20,
                                class_2561.method_43470("Scroll Direction"), (button, value) -> Main.config.wheelScrollDirection = value));

        this.method_37063(
                class_5676.<ScrollItemScaling>method_32606(value -> class_2561.method_43470(switch (value) {
                            case PROPORTIONAL -> "Multiple Wheel Clicks Move Multiple Items";
                            case ALWAYS_ONE -> "Always Move One Item (macOS Compatibility)";
                        }))
                        .method_32624(ScrollItemScaling.PROPORTIONAL, ScrollItemScaling.ALWAYS_ONE)
                        .method_32619(Main.config.scrollItemScaling)
                        .method_32617(this.field_22789 / 2 - 155, this.field_22790 / 6 + 24 * 4, 310, 20,
                                class_2561.method_43470("Scroll Scaling"), (button, value) -> Main.config.scrollItemScaling = value));

        this.method_37063(class_5676.method_32613(Config.debug)
                .method_32617(this.field_22789 / 2 - 155, this.field_22790 / 6 + 24 * 5, 310, 20,
                        class_2561.method_43470("Debug Mode"), (button, value) -> Config.debug = value));

        this.method_37063(class_4185.method_46430(class_5244.field_24334, button -> this.method_25419())
                .method_46434(this.field_22789 / 2 - 100, this.field_22790 - 27, 200, 20).method_46431());
    }

    @Override
    public void method_25419() {
        this.field_22787.method_1507(previous);
    }

    @Override
    public void method_25432() {
        Main.config.save();
    }
}
