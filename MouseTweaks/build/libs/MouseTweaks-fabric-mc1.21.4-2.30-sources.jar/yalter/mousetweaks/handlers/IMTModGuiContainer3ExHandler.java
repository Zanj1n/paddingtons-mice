package yalter.mousetweaks.handlers;

import yalter.mousetweaks.IGuiScreenHandler;
import yalter.mousetweaks.MouseButton;
import yalter.mousetweaks.api.IMTModGuiContainer3Ex;

import java.util.List;
import net.minecraft.class_1713;
import net.minecraft.class_1735;

public class IMTModGuiContainer3ExHandler implements IGuiScreenHandler {
    private final IMTModGuiContainer3Ex modGuiContainer;

    public IMTModGuiContainer3ExHandler(IMTModGuiContainer3Ex modGuiContainer) {
        this.modGuiContainer = modGuiContainer;
    }

    @Override
    public boolean isMouseTweaksDisabled() {
        return modGuiContainer.MT_isMouseTweaksDisabled();
    }

    @Override
    public boolean isWheelTweakDisabled() {
        return modGuiContainer.MT_isWheelTweakDisabled();
    }

    @Override
    public List<class_1735> getSlots() {
        return modGuiContainer.MT_getSlots();
    }

    @Override
    public class_1735 getSlotUnderMouse(double mouseX, double mouseY) {
        return modGuiContainer.MT_getSlotUnderMouse(mouseX, mouseY);
    }

    @Override
    public boolean disableRMBDraggingFunctionality() {
        return modGuiContainer.MT_disableRMBDraggingFunctionality();
    }

    @Override
    public void clickSlot(class_1735 slot, MouseButton mouseButton, boolean shiftPressed) {
        modGuiContainer.MT_clickSlot(slot,
                mouseButton.getValue(),
                shiftPressed ? class_1713.field_7794 : class_1713.field_7790);
    }

    @Override
    public boolean isCraftingOutput(class_1735 slot) {
        return modGuiContainer.MT_isCraftingOutput(slot);
    }

    @Override
    public boolean isIgnored(class_1735 slot) {
        return modGuiContainer.MT_isIgnored(slot);
    }
}
