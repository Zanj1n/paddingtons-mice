package yalter.mousetweaks.handlers;

import net.minecraft.class_1735;
import net.minecraft.class_481;

public class GuiContainerCreativeHandler extends GuiContainerHandler {
    public GuiContainerCreativeHandler(class_481 guiContainerCreative) {
        super(guiContainerCreative);
    }

    @Override
    public boolean isIgnored(class_1735 slot) {
        return (super.isIgnored(slot) || slot.field_7871 != mc.field_1724.method_31548());
    }
}
