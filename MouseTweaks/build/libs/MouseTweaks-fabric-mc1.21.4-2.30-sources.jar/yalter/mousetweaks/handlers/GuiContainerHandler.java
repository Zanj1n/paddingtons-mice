package yalter.mousetweaks.handlers;

import net.minecraft.class_1713;
import net.minecraft.class_1719;
import net.minecraft.class_1727;
import net.minecraft.class_1734;
import net.minecraft.class_1735;
import net.minecraft.class_310;
import net.minecraft.class_465;
import net.minecraft.world.inventory.*;
import yalter.mousetweaks.IGuiScreenHandler;
import yalter.mousetweaks.MouseButton;
import yalter.mousetweaks.api.MouseTweaksDisableWheelTweak;
import yalter.mousetweaks.api.MouseTweaksIgnore;
import yalter.mousetweaks.mixin.AbstractContainerScreenAccessor;

import java.util.List;

public class GuiContainerHandler implements IGuiScreenHandler {
    class_310 mc;
    private final class_465 screen;
    private final AbstractContainerScreenAccessor screenAccessor;

    public GuiContainerHandler(class_465 screen) {
        this.mc = class_310.method_1551();
        this.screen = screen;
        this.screenAccessor = (AbstractContainerScreenAccessor) screen;
    }

    @Override
    public boolean isMouseTweaksDisabled() {
        return screen.getClass().isAnnotationPresent(MouseTweaksIgnore.class);
    }

    @Override
    public boolean isWheelTweakDisabled() {
        return screen.getClass().isAnnotationPresent(MouseTweaksDisableWheelTweak.class);
    }

    @Override
    public List<class_1735> getSlots() {
        return screen.method_17577().field_7761;
    }

    @Override
    public class_1735 getSlotUnderMouse(double mouseX, double mouseY) {
        return screenAccessor.mousetweaks$invokeGetHoveredSlot(mouseX, mouseY);
    }

    @Override
    public boolean disableRMBDraggingFunctionality() {
        screenAccessor.mousetweaks$setSkipNextRelease(true);

        if (screenAccessor.mousetweaks$getIsQuickCrafting() && screenAccessor.mousetweaks$getQuickCraftingButton() == 1) {
            screenAccessor.mousetweaks$setIsQuickCrafting(false);
            return true;
        }

        return false;
    }

    @Override
    public void clickSlot(class_1735 slot, MouseButton mouseButton, boolean shiftPressed) {
        screenAccessor.mousetweaks$invokeSlotClicked(
                slot,
                slot.field_7874,
                mouseButton.getValue(),
                shiftPressed ? class_1713.field_7794 : class_1713.field_7790
        );
    }

    @Override
    public boolean isCraftingOutput(class_1735 slot) {
        return (slot instanceof class_1734
                || slot instanceof class_1719
                || slot instanceof class_1727);
    }

    @Override
    public boolean isIgnored(class_1735 slot) {
        return false;
    }
}
