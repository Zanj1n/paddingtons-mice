package yalter.mousetweaks;

import java.util.List;
import net.minecraft.class_1735;

public interface IGuiScreenHandler {
    boolean isMouseTweaksDisabled();

    boolean isWheelTweakDisabled();

    List<class_1735> getSlots();

    class_1735 getSlotUnderMouse(double mouseX, double mouseY);

    boolean disableRMBDraggingFunctionality();

    void clickSlot(class_1735 slot, MouseButton mouseButton, boolean shiftPressed);

    boolean isCraftingOutput(class_1735 slot);

    boolean isIgnored(class_1735 slot);
}
